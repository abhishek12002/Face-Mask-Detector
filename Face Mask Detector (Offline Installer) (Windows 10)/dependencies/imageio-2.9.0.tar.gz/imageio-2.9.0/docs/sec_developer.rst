=======================
Developer documentation
=======================

.. toctree::
  :maxdepth: 2
  
  Developer API <devapi>
  Writing plugins <plugins>
