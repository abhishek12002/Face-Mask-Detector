===============
Getting started
===============

.. toctree::
  :maxdepth: 2

  Installation <installation>
  Usage examples <examples>
  Transitioning from Scipy <scipy>
