.. _whatsnew:

**********************
"What's new" documents
**********************

These document the changes between minor (or major) versions of h5py.

.. toctree::

    3.2
    3.1
    3.0
    2.10
    2.9
    2.8
    2.7.1
    2.7
    2.6
    2.5
    2.4
    2.3
    2.2
    2.1
    2.0
